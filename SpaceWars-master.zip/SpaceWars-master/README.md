# SpaceWars

SpaceWars é um jogo antiguíssimo feito inicialmente na década de 60. Sua primeira versão foi deita para um PDP-1 por um grupo de hackers do MIT.

O código fonte em Assembly é https://gist.github.com/JonnieCache/4258114

E aqui estão alguns vídeos:

https://www.youtube.com/watch?time_continue=388&v=1EWQYAfuMYw

https://www.youtube.com/watch?time_continue=2&v=7bzWnaH-0sg

O jogo é composto por duas naves que estão num duelo espacial entre si nas órbitas de um planeta.

Esse projeto foi proposto pelo professor Doutor Marco Dimas Gubitoso, ministrando a disciplina de Técnicas de Programação I, do IME-USP.
Somos um grupo de três bacharelandos de Ciência da Computação e estamos animados para implementar esse projeto ao longo do semestre.
